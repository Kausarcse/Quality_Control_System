
<!-- Modal -->
<div class="modal fade" id="exampleDrying" tabindex="-1" role="dialog" aria-labelledby="exampleDryingLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleDryingLabel">Select Drying</h5>

      </div>


 <div class="row">
        <div class='col-md-offset-1 col-md-11 col-sm-11 col-xs-11'>
      <div id="RadioValueOfDrying">       
            <input type="radio" name="option" value="drying1"> <img  src="img/Drying/drying1.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="drying2"> <img  src="img/Drying/drying2.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="drying3"> <img  src="img/Drying/drying3.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="drying4"> <img  src="img/Drying/drying4.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="drying5"> <img  src="img/Drying/drying5.png" width="55" class="img-fluid" alt="Responsive image" ></input>
      </div>
      <div class='col-md-offset-1 col-md-11 col-sm-11 col-xs-11'>      
             <input type="radio" name="option" value="drying6"> <img  src="img/Drying/drying6.png" width="55" class="img-fluid" alt="Responsive image" ></input>
             <input type="radio" name="option" value="drying7"> <img  src="img/Drying/drying7.png" width="55" class="img-fluid" alt="Responsive image" ></input>
             <input type="radio" name="option" value="drying8"> <img  src="img/Drying/drying8.png" width="55" class="img-fluid" alt="Responsive image" ></input>
             <input type="radio" name="option" value="drying9"> <img  src="img/Drying/drying9.png" width="55" class="img-fluid" alt="Responsive image" ></input> 

                   
             <br/>        
      </div>

       <div class='col-md-offset-1 col-md-11 col-sm-11 col-xs-11'>      
            <input type="radio" name="option" value="drying10"> <img  src="img/Drying/drying10.png" width="55" class="img-fluid" alt="Responsive image" ></input>    
            <input type="radio" name="option" value="drying11"> <img  src="img/Drying/drying11.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="drying12"> <img  src="img/Drying/drying12.png" width="55" class="img-fluid" alt="Responsive image" ></input>
                   
             <br/>        
      </div>
 </div> </div>
      <div class="modal-footer">
            
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      <button id="DryingID1" type="button" class="btn btn-primary" data-dismiss="modal">Save changes</button>
      </div>
    </div>
  </div>
</div>





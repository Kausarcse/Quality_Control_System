
<!-- Modal -->
<div class="modal fade" id="exampleWashing" tabindex="-1" role="dialog" aria-labelledby="exampleWashingLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleWashingLabel">Select Washing</h5>

      </div>

      <div id="RadioValueOfWashing" >    

      <div class="row">
        <div class='col-md-offset-1 col-md-11 col-sm-11 col-xs-11'>

            <input type="radio" name="option" value="washing1"> <img  src="img/washing/washing1.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="washing2"> <img  src="img/washing/washing2.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="washing3"> <img  src="img/washing/washing3.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="washing4"> <img  src="img/washing/washing4.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="washing5"> <img  src="img/washing/washing5.png" width="55" class="img-fluid" alt="Responsive image" ></input>
             <input type="radio" name="option" value="washing6"> <img  src="img/washing/washing6.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="washing7"> <img  src="img/washing/washing7.png" width="55" class="img-fluid" alt="Responsive image" ></input>
          
        </div>
        
        <div class='col-md-offset-1 col-md-12 col-sm-12 col-xs-12'>

            
            <input type="radio" name="option" value="washing8"> <img  src="img/washing/washing8.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="washing9"> <img  src="img/washing/washing9.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="washing10"> <img  src="img/washing/washing10.png" width="55" class="img-fluid" alt="Responsive image" ></input>
             <input type="radio" name="option" value="washing11"> <img  src="img/washing/washing11.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="washing12"> <img  src="img/washing/washing12.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="washing13"> <img  src="img/washing/washing13.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="washing14"> <img  src="img/washing/washing14.png" width="55" class="img-fluid" alt="Responsive image" ></input>

            <br/>
            <input type="radio" name="option" value="washing15"> <img  src="img/washing/washing15.png" width="55" class="img-fluid" alt="Responsive image" ></input>
           
       </div>


         </div>      
             <br/>        
       </div>
      <div class="modal-footer">
            
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      <button id="WashingID1" type="button" class="btn btn-primary" data-dismiss="modal">Save changes</button>
      </div>
    </div>
  </div>
</div>





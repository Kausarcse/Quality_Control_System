
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Select Blenching</h5>
      
      </div>
 <div class="row">
        <div class='col-md-offset-1 col-md-11 col-sm-11 col-xs-11'>
      <div id="RadioValueOfBleaching">       
            <input type="radio" name="option" value="bleaching1"> <img  src="img/bleaching/bleaching1.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="bleaching2"> <img  src="img/bleaching/bleaching2.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="bleaching3"> <img  src="img/bleaching/bleaching3.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="bleaching4"> <img  src="img/bleaching/bleaching4.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="bleaching5"> <img  src="img/bleaching/bleaching5.png" width="55" class="img-fluid" alt="Responsive image" ></input>
       </div>    </div>    </div>
      <div class="modal-footer">
            
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      <button id="bleachingID1" type="button" class="btn btn-primary" data-dismiss="modal">Save changes</button>
      </div>
    </div>
  </div>
</div>






<!-- Modal -->
<div class="modal fade" id="exampleIron" tabindex="-1" role="dialog" aria-labelledby="exampleIronLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleIronLabel">Select Ironinginging</h5>
      
      </div>
 <div class="row">
        <div class='col-md-offset-1 col-md-11 col-sm-11 col-xs-11'>
      <div id="RadioValueOfIron">       
            <input type="radio" name="option" value="ironing1"> <img  src="img/ironing/ironing1.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="ironing2"> <img  src="img/ironing/ironing2.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="ironing3"> <img  src="img/ironing/ironing3.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="ironing4"> <img  src="img/ironing/ironing4.png" width="55" class="img-fluid" alt="Responsive image" ></input>
            <input type="radio" name="option" value="ironing5"> <img  src="img/ironing/ironing5.png" width="55" class="img-fluid" alt="Responsive image" ></input>
       </div>
        </div>
         </div>
      <div class="modal-footer">
            
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      <button id="ironingID1" type="button" class="btn btn-primary" data-dismiss="modal">Save changes</button>

      </div>
    </div>
  </div>
</div>







function copy_for_defining_qc_standard_for_individual_process_form_validation()
{

		
		if(document.getElementById("pp_number_for_searching").value=="select")
		{
      		alert("Please Select PP Number");
      		document.getElementById("pp_number_for_searching").focus();
      		return false;
		}
		else if(document.getElementById("version_number_for_searching").value=="select")
		{
      		alert("Please Select Version Number");
      		document.getElementById("version_number_for_searching").focus();
      		return false;
		}
		/*else if(document.getElementById("standard_for_for_searching").value=="select")
		{
      		alert("Please Select Standard For");
      		document.getElementById("standard_for_for_searching").focus();
      		return false;
		}*/

}


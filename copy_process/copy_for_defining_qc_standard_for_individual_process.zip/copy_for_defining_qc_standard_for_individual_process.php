<?php
session_start();
include('../login/db_connection_class.php');
$obj = new DB_Connection_Class();
$obj->connection();
/*
$user_id = $_SESSION['user_id'];
$password = $_SESSION['password'];

$sql="select * from hrm_info.user_login where user_id='$user_id' and `password`='$password'";

$result=mysql_query($sql) or die(mysql_error());
if(mysql_num_rows($result)<1)
{

	header('Location:logout.php');

}
*/
$process_id=$_GET['process_id'];
$sql_for_process_id = "SELECT * FROM `adding_process_to_version` WHERE `process_id`='$process_id'";

$res_for_process_id = mysqli_query($con, $sql_for_process_id);

$row_for_process_id = mysqli_fetch_assoc($res_for_process_id);
?>

<script type='text/javascript' src='copy_process_program/copy_for_defining_qc_standard_for_individual_process_form_validation.js'></script>


<style>

.form-group		/* This is for reducing Gap among Form's Fields */
{

	margin-bottom: 5px;

}

</style>

<script>

function Remove_Value_Of_This_Element(element_name)
{

	 document.getElementById(element_name).value='';
	 var alternate_field_of_date = "alternate_"+element_name;

	 if(typeof(alternate_field_of_date) != 'undefined' && alternate_field_of_date != null) // This is for deleting Alternative Field of Date if exists
	 {
		document.getElementById(alternate_field_of_date).value='';
	 }

}

function Reset_Radio_Button(radio_element)
{

		var radio_btn = document.getElementsByName(radio_element);
		for(var i=0;i<radio_btn.length;i++) 
		{
				radio_btn[i].checked = false;
		}


}

function Reset_Checkbox(checkbox_element)
{
		for(var i=0;i<checkbox_element.length;i++)
		{

				checkbox_element[i].checked = false;

		}
}

function reset_dropdown(select_element)
{

	  document.getElementById(select_element).selectedIndex = 0;

}

function Fill_Value_Of_Version_Number_Field_For_Searching(pp_number_for_searching)
{
    		//alert();
			//alert(pp_number_for_searching);
			var value_for_data= 'pp_number_value='+pp_number_for_searching;

            $.ajax({
			 		url: 'process_program/returning_version_number_details.php',
			 		dataType: 'text',
			 		type: 'post',
			 		contentType: 'application/x-www-form-urlencoded',
			 		data: value_for_data,
			 		      
			 		success: function( data, textStatus, jQxhr )
			 		{       
			 			    

                            //alert(data);
							/*var splitted_data= data.split('?fs?');*/
			 			    /*document.getElementById('customer_name').value=splitted_data[0]; 
			 			    document.getElementById('color').value=splitted_data[1]; 
			 			    document.getElementById('finish_width_in_inch').value=splitted_data[2]; 
			 			    document.getElementById('version_number').innerHTML=splitted_data[3]; */
			 				document.getElementById('version_number_for_searching').innerHTML=data;
			 				/*document.getElementById('copy_to_version_number').innerHTML=data;*/
			 				
							
							//document.getElementById('test').innerHTML=data;
							
			 		},
			 		error: function( jqXhr, textStatus, errorThrown )
			 		{       
			 				//console.log( errorThrown );
			 				alert(errorThrown);
			 		}
			}); // End of $.ajax({
}   /*End of function Fill_Value_Of_Version_Number_Field(pp_number)*/

function select_attached_proces_of_version()
{
	
			
			//alert('Here');
			//innerHTML=splitted_data[3];
			var pp_number = document.getElementById('pp_number_for_searching').value;
			var version_value = document.getElementById('version_number_for_searching').value;
			var splitted_version_value = version_value.split("?fs?");
			var version_name = splitted_version_value[0];
			var color = splitted_version_value[1];
			var version_id = splitted_version_value[4];
			//alert(pp_number+" "+version_number);
            $.ajax({
			 		url: 'process_program/returning_attached_proces_of_version.php',
			 		dataType: 'text',
			 		type: 'post',
			 		contentType: 'application/x-www-form-urlencoded',
			 		data: {pp_number_value:pp_number,version_number_value:version_name,color_value:color},
			 		      
			 		success: function( data, textStatus, jQxhr )
			 		{       
			 			    

                           // alert(data);
							/*var splitted_data= data.split('?fs?');*/
			 			    /*document.getElementById('customer_name').value=splitted_data[0]; 
			 			    document.getElementById('color').value=splitted_data[1]; 
			 			    document.getElementById('finish_width_in_inch').value=splitted_data[2]; 
			 			    document.getElementById('version_number').innerHTML=splitted_data[3]; */
			 				document.getElementById('standard_for_which_process').innerHTML=data;

			 				
							
							//document.getElementById('test').innerHTML=data;
							
			 		},
			 		error: function( jqXhr, textStatus, errorThrown )
			 		{       
			 				//console.log( errorThrown );
			 				alert(errorThrown);
			 		}
			}); // End of $.ajax({
	
	
}


function Fill_Value_Of_Version_Number_Field_For_Copy()
{   
	        var pp_number = document.getElementById('pp_number_for_searching').value;
			var version_value = document.getElementById('version_number_for_searching').value;
			var standard_for_which_process = document.getElementById('standard_for_which_process').value.toLowerCase();
			var standard_for_copy='defining_qc_standard_for_'+standard_for_which_process+'_process';
			var splitted_version_value = version_value.split("?fs?");
			var version_name = splitted_version_value[0];
			var color = splitted_version_value[1];
			var version_id = splitted_version_value[4];
 

            $.ajax({
			 		url: 'copy_process_program/returning_details_for_qc_result.php',
			 		dataType: 'text',
			 		type: 'post',
			 		contentType: 'application/x-www-form-urlencoded',
			 		data: {pp_number_value:pp_number,version_number_value:version_name,standard_for_copy:standard_for_copy,color_value:color},
			 		      
			 		success: function( data, textStatus, jQxhr )
			 		{       
			 			    

                            /*var splitted_data= data.split('?fs?');*/
			 			    /*document.getElementById('customer_name').value=splitted_data[0]; 
			 			    document.getElementById('color').value=splitted_data[1]; 
			 			    document.getElementById('finish_width_in_inch').value=splitted_data[2]; 
			 			    document.getElementById('version_number').innerHTML=splitted_data[3]; */
			 			    /*alert(data);*/
			 				//document.getElementById('copy_to_version_number').innerHTML=data;
			 				
			 				alert(data);
							
							//document.getElementById('test').innerHTML=data;
							
			 		},
			 		error: function( jqXhr, textStatus, errorThrown )
			 		{       
			 				//console.log( errorThrown );
			 				alert(errorThrown);
			 		}
			}); // End of $.ajax({
}   /*End of function Fill_Value_Of_Version_Number_Field(pp_number)*/

function fetching_qc_standard_defining_data()
{
	
       var validate = copy_for_defining_qc_standard_for_individual_process_form_validation();

       if(validate != false)
	   {

			var process_name = document.getElementById('standard_for_which_process').value;
			var mapping_fetchable_form = 
			{   
				"Singeing & Desizing"	: "process_program\\defining_qc_standard_for_singe_and_desize_process.php",
				"Bleaching"		 	: "process_program\\defining_qc_standard_for_bleaching_process.php", 
				"Mercerize"			: "process_program\\defining_qc_standard_for_mercerize_proces.php",
				"Ready For Mercerize": "process_program\\defining_qc_standard_for_ready_for_mercerize_process.php",
				"Equalize"          : "process_program\\defining_qc_standard_for_equalize_process.php",
				"Printing"          : "process_program\\defining_qc_standard_for_printing_process.php",
				"Curing"		 	: "process_program\\defining_qc_standard_for_curing_process.php", 
				"Washing"		 	: "process_program\\defining_qc_standard_for_washing_process.php", 
				"Finishing"		 	: "process_program\\defining_qc_standard_for_finishing_process.php", 
				"Calander"		 	: "process_program\\defining_qc_standard_for_calendering_process.php", 
				"Sanforize"		 	: "process_program\\defining_qc_standard_for_sanforizing_process.php", 
				"Raising"		 	: "process_program\\defining_qc_standard_for_ready_for_raising_process.php", 
				"Scouring & Bleaching"		 	: "process_program\\defining_qc_standard_for_scouring_bleaching_process.php", 
				"Scouring"		 	: "copy_process_program\\copy_from_scouring_process.php", 
				"Ready For Print"		 	: "process_program\\defining_qc_standard_for_ready_for_printing_process.php", 
				"Ready For Dyeing"		 	: "process_program\\defining_qc_standard_for_ready_for_dying_process.php", 
				"Ready For Raising"		 	: "process_program\\defining_qc_standard_for_ready_for_raising_process.php", 
				
				
				
			};
			
			//alert(mapping_fetchable_form[process_name]);
			
			var process_page_to_be_loaded = mapping_fetchable_form[process_name];
			$("#row_for_qc_standard_defining_form_loading").empty();
			$("#row_for_qc_standard_defining_form_loading").load(process_page_to_be_loaded,function() 
			{

				var selected_pp_number_value = document.getElementById('pp_number_for_searching').value;	
				var selected_pp_number_text = $("#pp_number_for_searching option:selected").html();
				/*var option_for_pp='<option value="'+selected_pp_number_value+'">'+selected_pp_number_text+'</option>';
				document.getElementById('pp_number').innerHTML= option_for_pp;
				document.getElementById('form-group_for_pp_number').style.display = "none";*/
				
				
				
				var selected_version_value = document.getElementById('version_number_for_searching').value;
				var selected_version_text = $("#version_number_for_searching option:selected").html();
				/*var option_for_version='<option value="'+selected_version_value+'">'+selected_version_text+'</option>';
				document.getElementById('version_number').innerHTML=option_for_version;
				document.getElementById('form-group_for_version_number').style.display = "none";*/
				
				
				
				var process_name_list = document.getElementById('standard_for_which_process').value;
				document.getElementById('standard_for_which_process').value=process_name_list;	
				//document.getElementById('form-group_for_standard_for_which_process').style.display = "none";
				
				
				
				var splitted_selected_version_number_value = selected_version_value.split('?fs?');
				var selected_color = splitted_selected_version_number_value[1];
				//document.getElementById('color').value=selected_color;
					
				var selected_finish_width_in_inch = splitted_selected_version_number_value[2];
				//document.getElementById('finish_width_in_inch').value=selected_finish_width_in_inch;
				
				var selected_customer = splitted_selected_version_number_value[3];
				//document.getElementById('customer_name').value = selected_customer;
				
			
			}
			); //End of $("#row_for_qc_standard_defining_form_loading").load(process_page_to_be_loaded,function()
			
		  	 
       }//End of if(validate != false)	
	
} // End of function fetching_qc_standard_defining_form()

function change_up_down_arrow_icon(icon_lcation)
{
	
	
	//alert(icon_lcation);
	var class_name = $('#'+icon_lcation).attr('class');
    //alert(class_name);
	if(class_name=="glyphicon glyphicon-chevron-up text-right")
	{
		$('#'+icon_lcation).removeClass();
		$('#'+icon_lcation).addClass("glyphicon glyphicon-chevron-down text-right");
	}
	else
	{
		$('#'+icon_lcation).removeClass();
		$('#'+icon_lcation).addClass("glyphicon glyphicon-chevron-up text-right");
		
	}
	
	
} // End of function change_up_down_arrow_icon(icon_lcation)

</script>


<div class="col-sm-12 col-md-12 col-lg-12">

 


		<div class="panel panel-default"> <!-- This div will create a block/panel for FORM -->

				<div class="panel-heading" style="color:#191970;">


                
	                <div class="row" data-toggle="collapse" data-target="#search_form_collpapsible_div" onClick="change_up_down_arrow_icon(this.childNodes[5].childNodes[1].id)"> <!-- Row for Panel Heading and Chevron Up Alingment -->
	                    <span class="col-sm-8"><b> Copy For Defining QC Standard For Individual Process Form</b></span>

	                    
	                    <div align="right" style="padding-right:10px;" id='test'> <i class="glyphicon glyphicon-chevron-up text-right"  id='panel_heading_icon'></i>
	                    </div>
	                </div> <!-- End of <div class="row" data-toggle="collapse" href="#demo"  Row for Panel Heading and Chevron Up Alingment -->
                    
                   
               
                </div> <!-- End of <div class="panel-heading" style="color:#191970;"> -->
                
                 
                 <div>
                 	 <nav aria-label="breadcrumb">
						  <ol class="breadcrumb">
						    <li class="breadcrumb-item active" aria-current="page" >Home</li>
						    <li class="breadcrumb-item"><a onclick="load_page('copy_process_program/copy_for_defining_qc_standard_for_individual_process.php')"> Copy For Defining QC Standard For Individual Process</a></li>
						  </ol>
					 </nav>
                 </div>
					

                
		<div id='search_form_collpapsible_div' class="collapse in"> <!-- For Making Collapsible Section -->
				<form class="form-horizontal " action="" style="margin-top:10px;" name="quickly_defining_qc_standard_for_individual_process_form" id="quickly_defining_qc_standard_for_individual_process_form">

                 

					<div class="form-group form-group-sm" id="form-group_for_pp_number_for_searching">
						    <label class="control-label col-sm-3" for="pp_number_for_searching" style="margin-right:0px; color:#00008B;">PP Number:</label>
							<div class="col-sm-5">
								<select  class="form-control" id="pp_number_for_searching" name="pp_number_for_searching" onchange="Fill_Value_Of_Version_Number_Field_For_Searching(this.value)">
											<option select="selected" value="select">Select PP Number</option>
											<?php 
												 $sql = 'select DISTINCT pp_number from `process_program_info` order by `pp_number`';
												 $result= mysqli_query($con,$sql) or die(mysqli_error());
												 while( $row = mysqli_fetch_array( $result))
												 {

													 echo '<option value="'.$row['pp_number'].'">'.$row['pp_number'].'</option>';

												 }

											 ?>
								</select>

							</div> <!-- End of <div class="col-sm-5"> -->
						</div> <!-- End of <div class="form-group form-group-sm" id="form-group_for_pp_number"> -->

						<div class="form-group form-group-sm" id="form-group_for_version_number_for_searching">
						<label class="control-label col-sm-3" for="version_number_for_searching" style="margin-right:0px; color:#00008B;">Copy From Version Number:</label>
							<div class="col-sm-5">
								<select  class="form-control" id="version_number_for_searching" name="version_number_for_searching" onchange="select_attached_proces_of_version()">
											<option select="selected" value="select">Select Version Number</option>
											<?php 
												 $sql = 'select DISTINCT version_name from `pp_wise_version_creation_info` order by `version_name`';
												 $result= mysqli_query($con,$sql) or die(mysqli_error());
												 while( $row = mysqli_fetch_array( $result))
												 {

													 echo '<option value="'.$row['version_name'].'">'.$row['version_name'].'</option>';

												 }

											 ?>
								</select>
							</div>
						</div> <!-- End of <div class="form-group form-group-sm" id="form-group_for_version_number"> -->



				
						
                     <div class="form-group form-group-sm" id="form-group_for_standard_for_which_process">
						<label class="control-label col-sm-3" for="standard_for_which_process" style="margin-right:0px; color:#00008B;">Copy Standard From:</label>
							<div class="col-sm-5">
                                

                                <input type="text" class="form-control" name="standard_for_which_process" id="standard_for_which_process" value="<?php echo $row_for_process_id['process_name'];?>" readonly>

                                <input type="hidden" class="form-control" name="process_id" id="process_id" value="<?php echo $row_for_process_id['process_id'];?>">

                              <!--   <input type="hidden" class="form-control" name="standard_for_which_process" id="standard_for_which_process" value="<?php echo $row_for_process_id['standard_for_which_process'];?>"> -->

								<!-- <select  class="form-control" id="standard_for_which_process" name="standard_for_which_process" onchange=" Fill_Value_Of_Version_Number_Field_For_Copy()">
											<option selected="selected" value="select">Select Standard For</option>
											<?php 
												 $sql = 'select DISTINCT process_name from `process_name` order by `process_name` ASC';
												 $result= mysqli_query($con,$sql) or die(mysqli_error());
												 while( $row = mysqli_fetch_array($result))
												 {

													 echo '<option value="'.$row['process_name'].'">'.$row['process_name'].'</option>';

												 }

											 ?>
								</select> -->
							</div>
								<!-- <i class="glyphicon glyphicon-remove" onclick="reset_dropdown('standard_for_which_process')" style="margin-top:6px;"></i> -->
					</div> <!-- End of <div class="form-group form-group-sm" id="form-group_for_standard_for"> -->

                    

<!-- 
				  <div class="form-group form-group-sm" id="form-group_for_copy_to_version_number">
	           				 <label class="control-label col-sm-3" for="copy_to_version_number" style="margin-right:0px; color:#00008B;">Copy To Version Number:</label>
				              <div class="col-sm-5">
				                <select  class="form-control" id="copy_to_version_number" name="copy_to_version_number">
				                      <option select="selected" value="select">Select Version Number</option>
				                      <?php 
				                         $sql = 'select DISTINCT version_name from `pp_wise_version_creation_info` order by `version_name`';
				                         $result= mysqli_query($con,$sql) or die(mysqli_error());
				                         while( $row = mysqli_fetch_array( $result))
				                         {

				                           echo '<option value="'.$row['version_name'].'">'.$row['version_name'].'</option>';

				                         }

				                       ?>
				                </select>
				              </div>
		            </div>  --><!-- End of <div class="form-group form-group-sm" id="form-group_for_version_number"> -->

			                        
						<div class="form-group form-group-sm">
								<div class="col-sm-offset-3 col-sm-5">
									<button type="button" class="btn btn-primary" onClick="fetching_qc_standard_defining_data()" >Copy</button>
									<button type="reset" class="btn btn-success">Reset</button>
								</div>
						</div>

				</form>
                
             </div> <!-- End of <div id='demo' class="show">  For Making Collapsible Section -->
			
		</div> <!-- End of <div class="panel panel-default"> -->
        
        <div class="row" id="row_for_qc_standard_defining_form_loading" >
						   
			<!-- This is Display Section. --> 
            <div align="center" style=" margin-top:140px;"> Welcome to Defining QC Standard For Individual Process</div>
               
						 
		</div> <!-- End of <div id="row_for_qc_standard_defining_form_loading"> -->

</div> <!-- End of <div class="col-sm-12 col-md-12 col-lg-12"> -->
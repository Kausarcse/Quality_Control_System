<?php

include('../login/db_connection_class.php');
$obj = new DB_Connection_Class();
$obj->connection();
$pp_number=$_POST['pp_number_value'];
$version_number=$_POST['version_number_value'];
$color_value=$_POST['color_value']; 
$standard_for_copy=$_POST['standard_for_copy'];
/*$value='<value value="select" selected="selected">Select Standard For</value>';*/

 /* echo $pp_number;*/

/*  echo '<value> value 1 </value> <value> value 2 </value>';
*/   
         
		/* $sql = 'select finish_width_in_inch_in_inch,color,version_name  from `pp_wise_version_creation_info` order by `finish_width_in_inch_in_inch`';*/
		 $sql = "select * from `$standard_for_copy` where pp_number='$pp_number' and `version_number`='$version_number' and `color`='$color_value'";
		 
		 $result= mysqli_query($con,$sql) or die(mysqli_error($con));
		 $fetch_all= mysqli_fetch_array( $result);
		 
		  $length=count($fetch_all);
		 
		  
		  $i=0;
		  for($i=0; $i < $length; $i++)
		  {
		  	/*echo $i;*/

		  	echo $fetch_all[$i];
		  	
		  }
		  
		   
         /*$get_data=impode("?fs?", $result);
         echo  $get_data;*/
		 /*while( $row = mysqli_fetch_array( $result))
		 {    
       
              $pp_number=$row['pp_number'];
              $color=$row['color'];
		  $value=$color.'?fs?'.$pp_number;



		 }
*/
		/*$sql_for_customer= 'select * from `process_program_info`,`pp_wise_version_creation_info` where `process_program_info`.pp_number=`pp_wise_version_creation_info`.pp_number ';
		 
		$customer_result= mysqli_query($con,$sql_for_customer) or die(mysqli_error($con));
		while ($customer_row = mysqli_fetch_array( $customer_result)) {
			$customer=$customer_row['customer_name'];
			
			
		}*/

	/*	 echo $customer."?fs?".$color."?fs?".$finish_width_in_inch."?fs?".$value;*/
		 //echo $get_data;


?>